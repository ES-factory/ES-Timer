/*
Based on Obdev's AVRUSB code and under the same license.

Copyright (C) 2021  Erfan Sn

ES Timer is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ES Timer is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see https://www.gnu.org/licenses/.
*/

#ifndef __ESTIMER_H__
#define __ESTIMER_H__

#include "cmdline_defs.h"
#include "usbdrv/usbdrv.h"
#include "ESTimerC.h"
#include <avr/io.h>
#include <TinyWireM.h>

#define SSD1306		     ADDRESS_OLED

#if SYSTEM_OS == WINDOWS
#   define LOCK_SHORTCUT 0x08, 0x0F
#elif SYSTEM_OS == LINUX
#   define LOCK_SHORTCUT 0x01 | 0x04, 0x0F
#else
#   define LOCK_SHORTCUT 0x01 | 0x08, 0x14
#endif

// caps lock LEDs
uint8_t previous_led_state = 0; 
uint8_t count_toggle_led = 0;

const PROGMEM uint8_t ssd1306InitSequence[] = {	
  0xAE,			    // Display OFF (sleep mode)
	0x20, 0b00,		// Set Memory Addressing Mode 00=Horizontal Addressing Mode; 01=Vertical Addressing Mode; 10=Page Addressing Mode (RESET); 11=Invalid
	0xB0,			    // Set Page Start Address for Page Addressing Mode, 0-7
#if FLIP_CONTENT_OLED // Set COM Output Scan Direction
	0xC0,                
#else
	0xC8,
#endif
	0x00,			    // ---set low column address
	0x10,			    // ---set high column address
	0x40,			    // --set start line address
	0x81, (uint8_t) (BRIGHTNESS_OLED * 0xFF),		// Set contrast control register
#if FLIP_CONTENT_OLED  // Set Segment Re-map. A0=address mapped; A1=address 127 mapped.
	0xA0,                
#else
	0xA1,
#endif              
	0xA6,       // Set display mode. A6=Normal; A7=Inverse
	0xA8, 0x3F, // Set multiplex ratio(1 to 64)		  
	0xA4,       // Output RAM to Display 0xA4=Output follows RAM content; 0xA5,Output ignores RAM content
	0xD3, 0x00, // Set display offset. 00 = no offset
	0xD5,       // --set display clock divide ratio/oscillator frequency
	0xF0,       // --set divide ratio
	0xD9, 0x22, // Set pre-charge period
	0xDA, 0x12, // Set com pins hardware configuration
	0xDB,       // --set vcomh
	0x20,       // 0x20,0.77xVcc
	0x8D, 0x14,	// Set DC-DC enable
	0xAF        // Display ON in normal mode
};

class ES_Timer {
  private:
    void ssd1306Fill(uint8_t pattern) {
      for (uint8_t page = 0; page < 8; page++) {
        ssd1306SendCommand(0xb0 + page);	// page0 - page1
        ssd1306SendCommand(0x00);		// low column start address
        ssd1306SendCommand(0x10);		// high column start address
        for (uint8_t row = 0; row < 128; row++) {
          ssd1306SendDataByte(pattern);
        }
      }
      ssd1306CursorTo(0, 0);
    }

    void ssd1306CursorTo(uint8_t x, uint8_t y) {
      TinyWireM.beginTransmission(SSD1306);
      TinyWireM.write(0x00);  // write command
      TinyWireM.write(0xb0 + y);
      TinyWireM.write(((x & 0xf0) >> 4) | 0x10); // | 0x10
      TinyWireM.write((x & 0x0f) | 0x01); // | 0x01
      TinyWireM.endTransmission();
    }

    void ssd1306SendCommand(uint8_t command) {
      TinyWireM.beginTransmission(SSD1306);
      TinyWireM.write(0x00);  // write command
      TinyWireM.write(command);
      TinyWireM.endTransmission();
    }

    void ssd1306SendDataByte(uint8_t dataByte) {
      TinyWireM.beginTransmission(SSD1306);
      TinyWireM.write(0x40);  //write data
      TinyWireM.write(dataByte);
      TinyWireM.endTransmission();
    }

    void releaseKey() {
      usbReportSend(0, 0);
    }

  public:
    ES_Timer() {
      usbBegin();
    }

    void delay(long durationInMilllis) {
      long last = millis();
      while (durationInMilllis > 0) {
        long now = millis();
        durationInMilllis -= now - last;
        last = now;
        usbPollWrapper();
      }
    }

    void goToSystemLockScreen() {
      usbReportSend(LOCK_SHORTCUT);

      previous_led_state = led_state;
      count_toggle_led = 0;
    }

    bool receivedRequestFromUser() {
      if (led_state != previous_led_state && count_toggle_led == 0) {
        count_toggle_led++;
      }
      bool is_received = led_state == previous_led_state && count_toggle_led == 1;
      if (is_received) releaseKey();
      return is_received;
    }

    void initSSD1306() {
      TinyWireM.begin();
      clearOLED();
      for (uint8_t index = 0; index < sizeof(ssd1306InitSequence); index++) {
        ssd1306SendCommand(pgm_read_byte(&ssd1306InitSequence[index]));
      }
    }

    void drawBitmap(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, const uint8_t bitmap[]) {
      uint16_t index = 0;

      for (uint8_t y = y0; y < y1; y++) {
        ssd1306CursorTo(x0, y);
        for (uint8_t x = x0; x < x1; x++) {
          ssd1306SendDataByte(pgm_read_byte(&bitmap[index++]));
        }
      }
      ssd1306CursorTo(0, 0);
    }

    void clearOLED() {
      ssd1306Fill(0x00);
    }
};

ES_Timer ESTimer = ES_Timer();

#endif 
