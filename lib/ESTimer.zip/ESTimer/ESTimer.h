/*
   Based on Obdev's AVRUSB code and under the same license.

   Modified for Digispark by ErfanSn
*/
#ifndef __ESTimer_h__
#define __ESTimer_h__

#include "usbdrv.h"

#if INCLUDE_OLED
#include <stdlib.h>
#include <avr/io.h>

#include <Wire.h>
#endif

#include <EEPROM.h>

#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <avr/delay.h>

#define BUFFER_SIZE 1

#define SSD1306		      0x3C	// Slave address

#define SLEEP           0x82
#define NONE            0x00

static uchar    idleRate;           // in 4 ms units

#if INCLUDE_OLED
const uint8_t ssd1306_init_sequence [] PROGMEM = {	// Initialization Sequence
  0xAE,			// Display OFF (sleep mode)
  0x20, 0b00,		// Set Memory Addressing Mode
  // 00=Horizontal Addressing Mode; 01=Vertical Addressing Mode;
  // 10=Page Addressing Mode (RESET); 11=Invalid
  0xB0,			// Set Page Start Address for Page Addressing Mode, 0-7
  0xC8,                 // Set COM Output Scan Direction
  0x00,			// ---set low column address
  0x10,			// ---set high column address
  0x40,			// --set start line address
  0x81, BRIGHTNESS_OLED * 0xFF,		// Set contrast control register
  0xA1,                 // Set Segment Re-map. A0=address mapped; A1=address 127 mapped.
  0xA6,			// Set display mode. A6=Normal; A7=Inverse
  0xA8, 0x3F,		// Set multiplex ratio(1 to 64)
  0xA4,			// Output RAM to Display
  // 0xA4=Output follows RAM content; 0xA5,Output ignores RAM content
  0xD3, 0x00,		// Set display offset. 00 = no offset
  0xD5,			// --set display clock divide ratio/oscillator frequency
  0xF0,			// --set divide ratio
  0xD9, 0x22,		// Set pre-charge period
  0xDA, 0x12,		// Set com pins hardware configuration
  0xDB,			// --set vcomh
  0x20,			// 0x20,0.77xVcc
  0x8D, 0x14,		// Set DC-DC enable
  0xAF			// Display ON in normal mode
};
#endif

const PROGMEM char usbHidReportDescriptor[] = { /* USB report descriptor */
  0x05, 0x01,							/* USAGE_PAGE (Generic Desktop) */
  0x09, 0x80,							/* USAGE (System Control) */
  0xa1, 0x01, 							/* COLLECTION (Application) */
  0x15, 0x00, 							/*    LOGICAL_MINIMUM (0) */
  0x26, 0xFF, 0x00,   						/*    LOGICAL_MAXIMUM (255) */
  0x19, 0x00, 							/*    USAGE_MINIMUM (Undefined) */
  0x29, 0xFF, 							/*    USAGE_MAXIMUM (System Menu Down) */
  0x95, 0x01, 							/*    REPORT_COUNT (1) */
  0x75, 0x08, 							/*    REPORT_SIZE (8) */
  0x81, 0x00, 							/*    INPUT (Data,Ary,Abs) */
  0xc0 								/* END_COLLECTION */
};

class ESTimerDevice {
  private:
    void write(uint8_t b) {
      usbPoll();
      reportBuffer[0] = b;
      usbSetInterrupt(this->reportBuffer, sizeof(this->reportBuffer));
    }

#if INCLUDE_OLED
    void ssd1306_send_command(uint8_t command) {
      ssd1306_send_command_start();
      Wire.write(command);
      ssd1306_send_command_stop();
    }

    void ssd1306_send_command_start() {
      Wire.beginTransmission(SSD1306);
      Wire.write(0x00);	// write command
    }

    void ssd1306_send_command_stop() {
      Wire.endTransmission();
    }

    void ssd1306_send_data_byte(uint8_t byte) {
      if (Wire.writeAvailable()) {
        ssd1306_send_data_stop();
        ssd1306_send_data_start();
      }
      Wire.write(byte);
    }

    void ssd1306_send_data_start() {
      Wire.beginTransmission(SSD1306);
      Wire.write(0x40);	//write data
    }

    void ssd1306_send_data_stop() {
      Wire.endTransmission();
    }

    void setCursor(uint8_t x, uint8_t y) {
      ssd1306_send_command_start();
      Wire.write(0xb0 + y);
      Wire.write(((x & 0xf0) >> 4) | 0x10); // | 0x10
      Wire.write((x & 0x0f) | 0x01); // | 0x01
      ssd1306_send_command_stop();
    }
#endif

  public:
    ESTimerDevice() {
      cli();
      usbDeviceDisconnect();
      _delay_ms(250);
      usbDeviceConnect();

      usbInit();

      sei();

#if INCLUDE_OLED
      Wire.begin();
      for (uint8_t i = 0; i < sizeof(ssd1306_init_sequence); i++) {
        if (i == sizeof(ssd1306_init_sequence) - 1) clear();
        ssd1306_send_command(pgm_read_byte(&ssd1306_init_sequence[i]));
      }
#endif
    }

    void delay(uint16_t milli) {
      uint16_t last = (uint16_t) millis();
      while (milli > 0) {
        uint16_t now = (uint16_t) millis();
        milli -= now - last;
        last = now;
        usbPoll();
      }
    }

    bool onSleepMode() {
      write(NONE);
      this->delay(500);
      return !usbInterruptIsReady();
    }

    void goToSleepMode() {
      write(SLEEP);
    }

#if INCLUDE_OLED
    void fill(uint8_t fill) {
      uint8_t m, n;
      for (m = 0; m < 8; m++) {
        ssd1306_send_command(0xb0 + m);	// page0 - page1
        ssd1306_send_command(0x00);		// low column start address
        ssd1306_send_command(0x10);		// high column start address
        ssd1306_send_data_start();
        for (n = 0; n < 128; n++) {
          ssd1306_send_data_byte(fill);
        }
        ssd1306_send_data_stop();
      }
      setCursor(0, 0);
    }

    void clear() {
      fill(0x00);
    }

    void drawBitmap(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, const uint8_t bitmap[]) {
      uint16_t j = 0;
      uint8_t y, x;
      for (y = y0; y < y1; y++) {
        setCursor(x0, y);
        ssd1306_send_data_start();
        for (x = x0; x < x1; x++) {
          ssd1306_send_data_byte(pgm_read_byte(&bitmap[j++]));
        }
        ssd1306_send_data_stop();
      }
      setCursor(0, 0);
    }

    void flipContent() {
      ssd1306_send_command(0xC0);
      ssd1306_send_command(0xA0);
    }
#endif

    uchar reportBuffer[BUFFER_SIZE];

};

ESTimerDevice ESTimer = ESTimerDevice();

#ifdef __cplusplus
extern "C" {
#endif
// USB_PUBLIC uchar usbFunctionSetup
uchar usbFunctionSetup(uchar data[8]) {
  usbRequest_t    *rq = (usbRequest_t *)((void *)data);

  usbMsgPtr = ESTimer.reportBuffer; //
  if ((rq->bmRequestType & USBRQ_TYPE_MASK) == USBRQ_TYPE_CLASS) {
    /* class request type */

    if (rq->bRequest == USBRQ_HID_GET_REPORT) {
      /* wValue: ReportType (highbyte), ReportID (lowbyte) */

      /* we only have one report type, so don't look at wValue */
      // TODO: Ensure it's okay not to return anything here?
      return 0;

    } else if (rq->bRequest == USBRQ_HID_GET_IDLE) {
      //usbMsgPtr = &idleRate;
      //return 1;
      return 0;

    } else if (rq->bRequest == USBRQ_HID_SET_IDLE) {
      idleRate = rq->wValue.bytes[1];

    }
  } else {
    /* no vendor specific requests implemented */
  }

  return 0;
}
#ifdef __cplusplus
} // extern "C"
#endif


#endif // __ESTimer_h__
