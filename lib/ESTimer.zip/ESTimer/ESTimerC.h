/*
Header file for ESTimerC.c

Copyright (C) 2021  Erfan Sn

ES Timer is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ES Timer is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see https://www.gnu.org/licenses/.
*/

#ifndef _ESTIMERC_H_
#define _ESTIMERC_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

extern uint8_t report_buffer[3];
extern uint8_t led_state;

void usbBegin();
void usbPollWrapper();
void usbReportSend(uint8_t modifier, uint8_t key);

#ifdef __cplusplus
}
#endif

#endif